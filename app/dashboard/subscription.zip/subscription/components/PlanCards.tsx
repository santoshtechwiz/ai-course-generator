"use client"

import { TooltipContent, TooltipTrigger, Tooltip, TooltipProvider } from "@/components/ui/tooltip"
import { Button } from "@/components/ui/button"
import { CardFooter, CardContent, CardDescription, CardTitle, CardHeader, Card } from "@/components/ui/card"
import { CreditCard, Zap, Rocket, Crown, Loader2, Check } from "lucide-react"
import { SavingsHighlight } from "./savings-highlight"
import type { SUBSCRIPTION_PLANS, SubscriptionPlanType, SubscriptionStatusType } from "./subscription.config"
import { Badge } from "@/components/ui/badge"

function PlanCards({
  plans,
  currentPlan,
  subscriptionStatus,
  loading,
  handleSubscribe,
  duration,
  isSubscribed,
  promoCode,
  isPromoValid,
  promoDiscount,
  getDiscountedPrice,
}: {
  plans: typeof SUBSCRIPTION_PLANS
  currentPlan: SubscriptionPlanType | null
  subscriptionStatus: SubscriptionStatusType | null
  loading: SubscriptionPlanType | null
  handleSubscribe: (planId: SubscriptionPlanType, duration: number) => Promise<void>
  duration: 1 | 6
  isSubscribed: boolean
  promoCode: string
  isPromoValid: boolean
  promoDiscount: number
  getDiscountedPrice: (originalPrice: number) => number
}) {
  const bestPlan = plans.find((plan) => plan.name === "PRO")
  const normalizedStatus = subscriptionStatus?.toUpperCase() || null
  const hasPaidPlan = currentPlan && currentPlan !== "FREE"
  const isOnFreePlan = currentPlan === "FREE"

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
      {plans.map((plan) => {
        const priceOption = plan.options.find((o) => o.duration === duration) || plan.options[0]
        const isPlanActive = currentPlan === plan.id
        const isBestValue = plan.name === bestPlan?.name
        const isFreePlan = plan.id === "FREE"
        const discountedPrice = getDiscountedPrice(priceOption.price)

        // Determine if button should be disabled
        let isButtonDisabled = false
        let buttonTooltip = ""

        if (loading === plan.id) {
          // Disable when this specific plan is loading
          isButtonDisabled = true
          buttonTooltip = "Processing your request..."
        } else if (isPlanActive) {
          // Disable the current active plan
          isButtonDisabled = true
          buttonTooltip = "This is your current active plan"
        } else if (isSubscribed && !isOnFreePlan) {
          // If user has a paid subscription (not Free), disable all buttons
          isButtonDisabled = true
          buttonTooltip = "Please manage your subscription in the billing portal"
        } else if (isOnFreePlan && isFreePlan) {
          // If user is on Free plan and this is the Free plan button
          isButtonDisabled = true
          buttonTooltip = "You are already on the Free plan"
        } else {
          // All other cases, enable the button
          isButtonDisabled = false
          buttonTooltip = isFreePlan ? "Start for Free" : `Upgrade to ${plan.name}`
        }

        // Determine button text
        let buttonText = "Subscribe Now"
        if (loading === plan.id) {
          buttonText = "Processing..."
        } else if (isPlanActive) {
          buttonText = "Current Plan"
        } else if (isFreePlan) {
          buttonText = "Start for Free"
        } else if (isSubscribed && !isOnFreePlan) {
          buttonText = "Manage Subscription"
        } else if (isOnFreePlan && !isFreePlan) {
          buttonText = "Upgrade"
        }

        return (
          <div key={plan.id} className={`${isBestValue ? "order-first lg:order-none" : ""}`}>
            <Card
              className={`flex flex-col h-full transition-all duration-300 hover:shadow-xl ${
                isPlanActive
                  ? "border-2 border-primary shadow-md dark:border-primary"
                  : "border-slate-200 dark:border-slate-700"
              } ${isBestValue ? "transform lg:scale-105 shadow-lg" : "shadow-sm"}`}
            >
              {isBestValue && (
                <div className="bg-gradient-to-r from-blue-500 to-purple-500 text-white text-center py-1.5 text-sm font-medium">
                  Most Popular
                </div>
              )}
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    {plan.id === "FREE" && <CreditCard className="h-5 w-5 mr-2 text-slate-500" />}
                    {plan.id === "BASIC" && <Zap className="h-5 w-5 mr-2 text-blue-500" />}
                    {plan.id === "PRO" && <Rocket className="h-5 w-5 mr-2 text-purple-500" />}
                    {plan.id === "ULTIMATE" && <Crown className="h-5 w-5 mr-2 text-amber-500" />}
                    <CardTitle className="text-xl">{plan.name}</CardTitle>
                  </div>
                  {isPlanActive && (
                    <Badge
                      variant={normalizedStatus === "ACTIVE" ? "success" : "destructive"}
                      className="whitespace-nowrap"
                    >
                      {normalizedStatus === "ACTIVE" ? "Active" : "Inactive"}
                    </Badge>
                  )}
                </div>
                <CardDescription>{plan.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mt-4 text-center">
                  <div className="flex items-baseline justify-center">
                    {isPromoValid && promoDiscount > 0 ? (
                      <>
                        <span className="text-2xl font-bold line-through text-muted-foreground">
                          ${priceOption.price}
                        </span>
                        <span className="text-3xl font-bold ml-2">${discountedPrice}</span>
                      </>
                    ) : (
                      <span className="text-3xl font-bold">${priceOption.price}</span>
                    )}
                    <span className="text-sm ml-1 text-muted-foreground">/{duration === 1 ? "month" : "6 months"}</span>
                  </div>
                  <SavingsHighlight plan={plan} duration={duration} />
                </div>
              </CardContent>
              <CardFooter>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <div className="w-full">
                        <Button
                          onClick={() => handleSubscribe(plan.id as SubscriptionPlanType, duration)}
                          disabled={isButtonDisabled}
                          variant={isPlanActive ? "outline" : isOnFreePlan && !isFreePlan ? "default" : "default"}
                          className={`w-full ${
                            isPlanActive ? "border-primary border-2" : ""
                          } ${isOnFreePlan && !isFreePlan ? "bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600" : ""} transition-all duration-300`}
                        >
                          {loading === plan.id ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Processing...
                            </>
                          ) : isPlanActive ? (
                            <>
                              <Check className="mr-2 h-4 w-4" /> {buttonText}
                            </>
                          ) : (
                            buttonText
                          )}
                        </Button>
                      </div>
                    </TooltipTrigger>
                    <TooltipContent>
                      {buttonTooltip ||
                        (isButtonDisabled
                          ? "Not available"
                          : isOnFreePlan && !isFreePlan
                            ? `Upgrade to ${plan.name}`
                            : `Subscribe to the ${plan.name} plan`)}
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </CardFooter>
            </Card>
          </div>
        )
      })}
    </div>
  )
}

export default PlanCards

