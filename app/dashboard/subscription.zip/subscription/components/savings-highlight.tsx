export function SavingsHighlight({ plan, duration }: { plan: any; duration: number }) {
    // Only show savings for 6-month plans
    if (duration !== 6 || plan.id === "FREE") return null
  
    // Calculate monthly price for the 6-month plan
    const sixMonthOption = plan.options.find((o: any) => o.duration === 6)
    const monthlyOption = plan.options.find((o: any) => o.duration === 1)
  
    if (!sixMonthOption || !monthlyOption) return null
  
    const monthlyCost = monthlyOption.price
    const sixMonthCost = sixMonthOption.price
    const monthlySixMonthCost = sixMonthCost / 6
    const savings = ((monthlyCost - monthlySixMonthCost) / monthlyCost) * 100
  
    return (
      <div className="mt-2 inline-block bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-100 text-xs font-medium px-2 py-1 rounded">
        Save {Math.round(savings)}% with 6-month plan
      </div>
    )
  }
  
  