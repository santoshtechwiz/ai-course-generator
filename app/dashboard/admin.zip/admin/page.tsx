import { redirect } from "next/navigation"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/authOptions"
import { Separator } from "@/components/ui/separator"
import { Suspense } from "react"
import { LoadingSkeleton } from "./components/loading-skeleton"


export const metadata = {
  title: "Admin Dashboard",
  description: "Overview of your platform's performance",
}

export default async function AdminDashboard() {
  // Check if user is authenticated and is an admin
  const session = await getServerSession(authOptions)

  // If no session or user is not an admin, redirect to the homepage
  if (!session || !session.user || session.user.isAdmin !== true) {
    redirect("/")
  }

  return (
    <div className="space-y-6">
      <Suspense fallback={<LoadingSkeleton />}>
       
      </Suspense>

      <Separator />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <h2 className="text-2xl font-bold tracking-tight mb-4">Quick Actions</h2>
          <div className="grid grid-cols-2 gap-4">
            <a
              href="/dashboard/admin/users"
              className="block p-6 bg-card hover:bg-muted/50 rounded-lg border transition-colors"
            >
              <h3 className="font-medium mb-1">User Management</h3>
              <p className="text-sm text-muted-foreground">Manage users and subscriptions</p>
            </a>
            <a
              href="/dashboard/admin/email"
              className="block p-6 bg-card hover:bg-muted/50 rounded-lg border transition-colors"
            >
              <h3 className="font-medium mb-1">Email Campaigns</h3>
              <p className="text-sm text-muted-foreground">Create and send email campaigns</p>
            </a>
            <a
              href="/dashboard/admin/contact"
              className="block p-6 bg-card hover:bg-muted/50 rounded-lg border transition-colors"
            >
              <h3 className="font-medium mb-1">Contact Inquiries</h3>
              <p className="text-sm text-muted-foreground">Manage user inquiries</p>
            </a>
            <a
              href="/dashboard/admin/settings"
              className="block p-6 bg-card hover:bg-muted/50 rounded-lg border transition-colors"
            >
              <h3 className="font-medium mb-1">Settings</h3>
              <p className="text-sm text-muted-foreground">Configure platform settings</p>
            </a>
          </div>
        </div>

        <div>
          <h2 className="text-2xl font-bold tracking-tight mb-4">Recent Activity</h2>
          <div className="border rounded-lg divide-y">
            <div className="p-4">
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-medium">New user registered</p>
                  <p className="text-sm text-muted-foreground">John Smith created an account</p>
                </div>
                <span className="text-xs text-muted-foreground">2 hours ago</span>
              </div>
            </div>
            <div className="p-4">
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-medium">Campaign sent</p>
                  <p className="text-sm text-muted-foreground">Spring Promotion sent to 156 users</p>
                </div>
                <span className="text-xs text-muted-foreground">5 hours ago</span>
              </div>
            </div>
            <div className="p-4">
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-medium">New contact inquiry</p>
                  <p className="text-sm text-muted-foreground">Support request from Sarah Johnson</p>
                </div>
                <span className="text-xs text-muted-foreground">Yesterday</span>
              </div>
            </div>
            <div className="p-4">
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-medium">Subscription upgraded</p>
                  <p className="text-sm text-muted-foreground">Michael Brown upgraded to Premium</p>
                </div>
                <span className="text-xs text-muted-foreground">2 days ago</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
