import { getAuthSession } from "@/lib/authOptions"
import { generateFlashCards } from "@/lib/chatgpt/ai-service"
import prisma from "@/lib/db"
import { titleToSlug } from "@/lib/slug"
import { NextResponse } from "next/server"
import { z } from "zod"
import type { User } from "@prisma/client"

// Input validation schema
const createFlashcardSchema = z.object({
  topic: z.string().min(1, "Topic is required"),
  count: z.number().int().positive().default(5),
})

// Type for flashcard data from AI service
interface FlashCardData {
  question: string
  answer: string
}

// Generate a unique slug with better performance
async function generateUniqueSlug(topic: string): Promise<string> {
  const baseSlug = titleToSlug(topic)

  // Check if slug exists with a more efficient query
  const existingCount = await prisma.userQuiz.count({
    where: { slug: baseSlug },
  })

  if (existingCount === 0) return baseSlug

  // If slug exists, try with a random suffix
  const randomSuffix = Math.floor(Math.random() * 10000)
    .toString()
    .padStart(4, "0")
  const newSlug = `${baseSlug}-${randomSuffix}`

  // Double-check the new slug doesn't exist
  const newSlugExists = await prisma.userQuiz.count({
    where: { slug: newSlug },
  })

  // In the rare case of a collision, use timestamp as fallback
  if (newSlugExists > 0) {
    const timestamp = Date.now().toString().slice(-6)
    return `${baseSlug}-${timestamp}`
  }

  return newSlug
}

// Centralized error response handler
function handleError(error: unknown, defaultMessage = "Internal server error") {
  console.error("API Error:", error)

  if (error instanceof z.ZodError) {
    return NextResponse.json({ error: "Validation error", details: error.format() }, { status: 400 })
  }

  if (error instanceof Error) {
    // Handle specific error types
    if (error.message.includes("Authentication required")) {
      return NextResponse.json({ error: error.message }, { status: 401 })
    }

    if (error.message.includes("AI service")) {
      return NextResponse.json({ error: "AI service error", message: error.message }, { status: 503 })
    }

    if (error.message.includes("credits")) {
      return NextResponse.json({ error: "Credit operation failed", message: error.message }, { status: 400 })
    }

    if (error.message.includes("not found")) {
      return NextResponse.json({ error: error.message }, { status: 404 })
    }

    if (error.message.includes("Insufficient")) {
      return NextResponse.json({ error: error.message }, { status: 403 })
    }

    return NextResponse.json({ error: defaultMessage, message: error.message }, { status: 500 })
  }

  return NextResponse.json({ error: defaultMessage }, { status: 500 })
}

// Verify user authentication and return user data
async function authenticateUser(): Promise<{
  session: { user: { id: string } }
  user: Pick<User, "id" | "credits">
}> {
  const session = await getAuthSession()

  if (!session?.user) {
    throw new Error("Authentication required")
  }

  const user = await prisma.user.findUnique({
    where: { id: session.user.id },
    select: { id: true, credits: true },
  })

  if (!user) {
    throw new Error("User not found")
  }

  return { session, user }
}

export async function POST(req: Request) {
  try {
    // Authenticate user
    const { session, user } = await authenticateUser()

    // Parse and validate input
    const body = await req.json()
    const { topic, count } = createFlashcardSchema.parse(body)

    // Check credits
    if (user.credits < 1) {
      throw new Error("Insufficient credits. You need at least 1 credit to generate flashcards")
    }

    // Generate unique slug
    const slug = await generateUniqueSlug(topic)

    // Use a transaction for database operations
    const result = await prisma.$transaction(async (tx) => {
      // Generate flashcards
      const flashcards = (await generateFlashCards(topic, count)) as FlashCardData[]

      if (!flashcards || flashcards.length === 0) {
        throw new Error("Failed to generate flashcards")
      }

      // Create new quiz with flashcards
      const newQuiz = await tx.userQuiz.create({
        data: {
          topic,
          quizType: "flashcard",
          slug,
          timeStarted: new Date(),
          userId: session.user.id,
        },
      })

      // Create flashcards
      await tx.flashCard.createMany({
        data: flashcards.map((flashcard: FlashCardData) => ({
          question: flashcard.question,
          answer: flashcard.answer,
          userId: session.user.id,
          difficulty: "hard",
          userQuizId: newQuiz.id,
        })),
      })

      // Deduct one credit
      await tx.user.update({
        where: { id: session.user.id },
        data: { credits: { decrement: 1 } },
      })

      return newQuiz
    })

    return NextResponse.json(
      {
        success: true,
        data: result,
        message: "Flashcards created successfully. 1 credit has been deducted.",
      },
      { status: 201 },
    )
  } catch (error) {
    return handleError(error, "Failed to generate flashcards")
  }
}

export async function GET(req: Request) {
  try {
    // Authenticate user
    const { session } = await authenticateUser()

    // Get slug parameter
    const { searchParams } = new URL(req.url)
    const slug = searchParams.get("slug")

    if (slug) {
      // Get specific quiz by slug
      const quiz = await prisma.userQuiz.findUnique({
        where: {
          slug,
         
        },
        include: {
          flashCards: {
            orderBy: { createdAt: "desc" },
          },
        },
      })

      if (!quiz) {
        throw new Error("Flashcard set not found")
      }

      return NextResponse.json(
        {
          success: true,
          data: {
            quiz,
            flashCards: quiz.flashCards,
          },
        },
        { status: 200 },
      )
    } else {
      // Get all user's quizzes
      const quizzes = await prisma.userQuiz.findMany({
        where: {
          userId: session.user.id,
          quizType: "flashcard",
        },
        include: {
          flashCards: {
            orderBy: { createdAt: "desc" },
          },
        },
        orderBy: {
          createdAt: "desc",
        },
      })

      return NextResponse.json(
        {
          success: true,
          data: {
            quizzes,
          },
        },
        { status: 200 },
      )
    }
  } catch (error) {
    return handleError(error, "Failed to fetch flashcards")
  }
}

