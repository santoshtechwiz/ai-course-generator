"use client"

import { motion } from "framer-motion"

const TeamIllustration = () => {
  return (
    <svg
      width="100%"
      height="100%"
      viewBox="0 0 800 600"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="max-w-full max-h-full"
      preserveAspectRatio="xMidYMid meet"
    >
      {/* Background elements */}
      <motion.circle
        cx="400"
        cy="300"
        r="250"
        fill="url(#teamGradient)"
        opacity="0.1"
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 0.1 }}
        transition={{ duration: 1, ease: "easeOut" }}
      />

      <motion.circle
        cx="400"
        cy="300"
        r="200"
        stroke="url(#teamGradient)"
        strokeWidth="2"
        strokeDasharray="5 5"
        fill="none"
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 1, delay: 0.2, ease: "easeOut" }}
      />

      {/* Team members */}
      <g>
        {/* Center person */}
        <motion.g
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <circle cx="400" cy="300" r="60" fill="url(#personGradient1)" />
          <circle cx="400" cy="260" r="25" fill="#FFFFFF" />
          <rect x="370" y="290" width="60" height="70" rx="30" fill="#FFFFFF" />
        </motion.g>

        {/* Left person */}
        <motion.g
          initial={{ x: -20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
        >
          <circle cx="280" cy="300" r="50" fill="url(#personGradient2)" />
          <circle cx="280" cy="270" r="20" fill="#FFFFFF" />
          <rect x="255" y="295" width="50" height="55" rx="25" fill="#FFFFFF" />
        </motion.g>

        {/* Right person */}
        <motion.g
          initial={{ x: 20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.4, ease: "easeOut" }}
        >
          <circle cx="520" cy="300" r="50" fill="url(#personGradient3)" />
          <circle cx="520" cy="270" r="20" fill="#FFFFFF" />
          <rect x="495" y="295" width="50" height="55" rx="25" fill="#FFFFFF" />
        </motion.g>

        {/* Top person */}
        <motion.g
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.6, ease: "easeOut" }}
        >
          <circle cx="400" cy="180" r="45" fill="url(#personGradient4)" />
          <circle cx="400" cy="155" r="18" fill="#FFFFFF" />
          <rect x="378" y="175" width="45" height="50" rx="22.5" fill="#FFFFFF" />
        </motion.g>

        {/* Bottom person */}
        <motion.g
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.8, ease: "easeOut" }}
        >
          <circle cx="400" cy="420" r="45" fill="url(#personGradient5)" />
          <circle cx="400" cy="395" r="18" fill="#FFFFFF" />
          <rect x="378" y="415" width="45" height="50" rx="22.5" fill="#FFFFFF" />
        </motion.g>
      </g>

      {/* Connection lines with animation */}
      <motion.g
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 1, ease: "easeOut" }}
      >
        <motion.line
          x1="340"
          y1="300"
          x2="280"
          y2="300"
          stroke="url(#lineGradient)"
          strokeWidth="2"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 0.8, ease: "easeInOut" }}
        />
        <motion.line
          x1="460"
          y1="300"
          x2="520"
          y2="300"
          stroke="url(#lineGradient)"
          strokeWidth="2"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 0.8, ease: "easeInOut", delay: 0.2 }}
        />
        <motion.line
          x1="400"
          y1="240"
          x2="400"
          y2="180"
          stroke="url(#lineGradient)"
          strokeWidth="2"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 0.8, ease: "easeInOut", delay: 0.4 }}
        />
        <motion.line
          x1="400"
          y1="360"
          x2="400"
          y2="420"
          stroke="url(#lineGradient)"
          strokeWidth="2"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 0.8, ease: "easeInOut", delay: 0.6 }}
        />
      </motion.g>

      {/* Floating particles with advanced animation */}
      <motion.circle
        cx="350"
        cy="220"
        r="5"
        fill="url(#particleGradient)"
        animate={{
          y: [0, -10, 0],
          opacity: [0.7, 1, 0.7],
          boxShadow: [
            "0 0 0 0 rgba(var(--primary-rgb), 0)",
            "0 0 0 3px rgba(var(--primary-rgb), 0.3)",
            "0 0 0 0 rgba(var(--primary-rgb), 0)",
          ],
        }}
        transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
      />
      <motion.circle
        cx="450"
        cy="220"
        r="5"
        fill="url(#particleGradient)"
        animate={{
          y: [0, -15, 0],
          opacity: [0.7, 1, 0.7],
          boxShadow: [
            "0 0 0 0 rgba(var(--primary-rgb), 0)",
            "0 0 0 3px rgba(var(--primary-rgb), 0.3)",
            "0 0 0 0 rgba(var(--primary-rgb), 0)",
          ],
        }}
        transition={{ duration: 4, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut", delay: 0.5 }}
      />
      <motion.circle
        cx="350"
        cy="380"
        r="5"
        fill="url(#particleGradient)"
        animate={{
          y: [0, 15, 0],
          opacity: [0.7, 1, 0.7],
          boxShadow: [
            "0 0 0 0 rgba(var(--primary-rgb), 0)",
            "0 0 0 3px rgba(var(--primary-rgb), 0.3)",
            "0 0 0 0 rgba(var(--primary-rgb), 0)",
          ],
        }}
        transition={{ duration: 3.5, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut", delay: 1 }}
      />
      <motion.circle
        cx="450"
        cy="380"
        r="5"
        fill="url(#particleGradient)"
        animate={{
          y: [0, 10, 0],
          opacity: [0.7, 1, 0.7],
          boxShadow: [
            "0 0 0 0 rgba(var(--primary-rgb), 0)",
            "0 0 0 3px rgba(var(--primary-rgb), 0.3)",
            "0 0 0 0 rgba(var(--primary-rgb), 0)",
          ],
        }}
        transition={{ duration: 2.5, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut", delay: 1.5 }}
      />
      <motion.circle
        cx="220"
        cy="300"
        r="5"
        fill="url(#particleGradient)"
        animate={{
          x: [0, -10, 0],
          opacity: [0.7, 1, 0.7],
          boxShadow: [
            "0 0 0 0 rgba(var(--primary-rgb), 0)",
            "0 0 0 3px rgba(var(--primary-rgb), 0.3)",
            "0 0 0 0 rgba(var(--primary-rgb), 0)",
          ],
        }}
        transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut", delay: 0.2 }}
      />
      <motion.circle
        cx="580"
        cy="300"
        r="5"
        fill="url(#particleGradient)"
        animate={{
          x: [0, 10, 0],
          opacity: [0.7, 1, 0.7],
          boxShadow: [
            "0 0 0 0 rgba(var(--primary-rgb), 0)",
            "0 0 0 3px rgba(var(--primary-rgb), 0.3)",
            "0 0 0 0 rgba(var(--primary-rgb), 0)",
          ],
        }}
        transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut", delay: 0.7 }}
      />

      {/* Data flow animation */}
      <motion.circle
        cx="340"
        cy="300"
        r="4"
        fill="#FFFFFF"
        initial={{ opacity: 0 }}
        animate={{
          opacity: [0, 1, 0],
          x: [340, 290, 280],
        }}
        transition={{
          duration: 2,
          repeat: Number.POSITIVE_INFINITY,
          repeatDelay: 3,
          ease: "easeInOut",
          delay: 2,
        }}
      />

      <motion.circle
        cx="460"
        cy="300"
        r="4"
        fill="#FFFFFF"
        initial={{ opacity: 0 }}
        animate={{
          opacity: [0, 1, 0],
          x: [460, 510, 520],
        }}
        transition={{
          duration: 2,
          repeat: Number.POSITIVE_INFINITY,
          repeatDelay: 3,
          ease: "easeInOut",
          delay: 2.5,
        }}
      />

      <motion.circle
        cx="400"
        cy="240"
        r="4"
        fill="#FFFFFF"
        initial={{ opacity: 0 }}
        animate={{
          opacity: [0, 1, 0],
          y: [240, 200, 180],
        }}
        transition={{
          duration: 2,
          repeat: Number.POSITIVE_INFINITY,
          repeatDelay: 3,
          ease: "easeInOut",
          delay: 3,
        }}
      />

      <motion.circle
        cx="400"
        cy="360"
        r="4"
        fill="#FFFFFF"
        initial={{ opacity: 0 }}
        animate={{
          opacity: [0, 1, 0],
          y: [360, 400, 420],
        }}
        transition={{
          duration: 2,
          repeat: Number.POSITIVE_INFINITY,
          repeatDelay: 3,
          ease: "easeInOut",
          delay: 3.5,
        }}
      />

      {/* Gradients */}
      <defs>
        <linearGradient id="teamGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="var(--color-primary)" />
          <stop offset="100%" stopColor="var(--color-primary-light, hsl(var(--primary) / 0.5))" />
        </linearGradient>

        <linearGradient id="personGradient1" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#FF6B6B" />
          <stop offset="100%" stopColor="#FF8E8E" />
        </linearGradient>

        <linearGradient id="personGradient2" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#4ECDC4" />
          <stop offset="100%" stopColor="#7EEEE7" />
        </linearGradient>

        <linearGradient id="personGradient3" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#FFD166" />
          <stop offset="100%" stopColor="#FFE599" />
        </linearGradient>

        <linearGradient id="personGradient4" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#6A0572" />
          <stop offset="100%" stopColor="#AB83A1" />
        </linearGradient>

        <linearGradient id="personGradient5" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#1A936F" />
          <stop offset="100%" stopColor="#88D498" />
        </linearGradient>

        <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="var(--color-primary, hsl(var(--primary)))" stopOpacity="0.3" />
          <stop offset="100%" stopColor="var(--color-primary, hsl(var(--primary)))" stopOpacity="0.7" />
        </linearGradient>

        <linearGradient id="particleGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="var(--color-primary, hsl(var(--primary)))" />
          <stop offset="100%" stopColor="var(--color-primary, hsl(var(--primary)))" stopOpacity="0.5" />
        </linearGradient>
      </defs>
    </svg>
  )
}

export default TeamIllustration
