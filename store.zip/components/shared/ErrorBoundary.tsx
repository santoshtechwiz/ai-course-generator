import { Component, type ErrorInfo, type ReactNode } from "react"

interface Props {
  children?: ReactNode
  fallback: ReactNode
}

interface State {
  hasError: boolean
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
  }

  public static getDerivedStateFromError(_: Error): State {
    return { hasError: true }
  }

  public componentDidCatch(error: unknown, errorInfo: ErrorInfo) {
    // Fix: Safely log the error by handling potential undefined or non-iterable values
    try {
      console.error("Uncaught error:", error)
      console.error("Error info:", errorInfo)
    } catch (loggingError) {
      console.error("Failed to log error details:", loggingError)
    }
  }

  public render() {
    if (this.state.hasError) {
      return this.props.fallback
    }

    return this.props.children
  }
}
