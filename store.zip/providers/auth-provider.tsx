"use client"

import type React from "react"

import { createContext, useContext, useEffect, useState, useCallback, useMemo } from "react"
import { useSession } from "next-auth/react"

// Define the auth context type
interface AuthContextType {
  isLoading: boolean
  isAuthenticated: boolean
  user: any
  isAdmin: boolean
  refreshUserData: () => Promise<void>
}

// Create the auth context
const AuthContext = createContext<AuthContextType | undefined>(undefined)

// Create the auth provider component
export function AuthProvider({ children }: { children: React.ReactNode }) {
  const { data: session, status } = useSession()
  const [isLoading, setIsLoading] = useState<boolean>(true)
  const [subscriptionData, setSubscriptionData] = useState<{
    plan: string | null
    status: string | null
  }>({ plan: null, status: null })

  // Function to fetch subscription status
  const fetchSubscriptionStatus = useCallback(async (userId: string) => {
    if (!userId) return

    try {
      const response = await fetch(`/api/subscriptions/status?userId=${userId}`, {
        method: "GET",
        headers: {
          "Cache-Control": "no-cache",
        },
      })

      if (response.ok) {
        const data = await response.json()
        setSubscriptionData({
          plan: data.subscriptionPlan,
          status: data.isActive ? "ACTIVE" : "INACTIVE",
        })
      }
    } catch (error) {
      console.error("Error fetching subscription status:", error)
    }
  }, [])

  // Function to refresh user data
  const refreshUserData = useCallback(async () => {
    if (session?.user?.id) {
      await fetchSubscriptionStatus(session.user.id)
    }
  }, [session?.user?.id, fetchSubscriptionStatus])

  // Effect to handle session changes
  useEffect(() => {
    const handleSessionChange = async () => {
      setIsLoading(true)

      if (status === "authenticated" && session?.user?.id) {
        await fetchSubscriptionStatus(session.user.id)
      }

      setIsLoading(status === "loading")
    }

    handleSessionChange()
  }, [status, session, fetchSubscriptionStatus])

  // Memoize the context value to prevent unnecessary re-renders
  const contextValue = useMemo(
    () => ({
      isLoading,
      isAuthenticated: status === "authenticated",
      user: session?.user,
      isAdmin: session?.user?.isAdmin || false,
      refreshUserData,
    }),
    [isLoading, status, session, refreshUserData],
  )

  return <AuthContext.Provider value={contextValue}>{children}</AuthContext.Provider>
}

// Create a hook to use the auth context
export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
