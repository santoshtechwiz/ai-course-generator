import type React from "react"
import type { Metadata } from "next"
import { Suspense } from "react"
import { getServerSession } from "next-auth"

import { authOptions } from "@/lib/authOptions"
import { NavigationEvents } from "./NavigationEvents"
import { Chatbot } from "@/components/Chatbot"
import MainNavbar from "@/components/shared/MainNavbar"


export const metadata: Metadata = {
  title: "Dashboard",
  description: "User dashboard for managing courses and quizzes",
}

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  // Check if user is authenticated
  const session = await getServerSession(authOptions)

 

  return (
    <div className="flex flex-col min-h-screen">
      <main className="flex-1">
        <MainNavbar></MainNavbar>
        <Suspense fallback={<div>Loading...</div>}>
          <NavigationEvents />
        </Suspense>
        {children}
      </main>
      <Suspense fallback={null}>
        {session?.user?.id && <Chatbot userId={session.user.id} />}
      </Suspense>
    </div>
  )
}
