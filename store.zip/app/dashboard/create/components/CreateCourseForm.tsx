"use client"

import * as React from "react"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"
import { useMutation } from "@tanstack/react-query"
import { useForm, type SubmitHandler } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import axios from "axios"
import { signIn, useSession } from "next-auth/react"
import { Pencil, FileText, Eye } from "lucide-react"

import { BasicInfoStep } from "./BasicInfoStep"
import { ContentStep } from "./ContentStep"
import { PreviewStep } from "./PreviewStep"
import { ConfirmationDialog } from "./ConfirmationDialog"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { cn } from "@/lib/utils"

import { type CreateCourseInput, createCourseSchema } from "@/schema/schema"
import useSubscriptionStore from "@/store/useSubscriptionStore"


import type { QueryParams } from "@/app/types/types"
import { useEffect } from "react"

interface CourseCreationFormProps {
  maxQuestions: number
  params: QueryParams
}

export default function CourseCreationForm({ maxQuestions, params }: CourseCreationFormProps) {
  const [step, setStep] = React.useState(1)
  const [showConfirmDialog, setShowConfirmDialog] = React.useState(false)
  const totalSteps = 3

  const { subscriptionStatus } = useSubscriptionStore()
  const { data: session, status: authStatus } = useSession()
  const router = useRouter()
  const { toast } = useToast()
  const [availableCredits, setAvailableCredits] = React.useState(subscriptionStatus?.credits)

  React.useEffect(() => {
    if (subscriptionStatus) {
      setAvailableCredits(subscriptionStatus.credits)
    }
  }, [subscriptionStatus])

  const {
    control,
    handleSubmit,
    watch,
    setValue,
    formState: { errors, isSubmitting },
  } = useForm<CreateCourseInput>({
    resolver: zodResolver(createCourseSchema),
    defaultValues: {
      title: params.title || "",
      description: "",
      category: "",
      units: [""],
    },
  })

  useEffect(() => {
    if (params.title) {
      setValue("title", params.title)
    }
  }, [params.title, setValue])

  const createCourseMutation = useMutation({
    mutationFn: async (data: CreateCourseInput) => {
      const response = await axios.post("/api/course", data)
      return response.data
    },
    onSuccess: (data) => {
      toast({
        title: "Success",
        description: "Course created successfully",
      })
      setAvailableCredits((prev) => (prev ?? 0) - 1)
      router.push(`/dashboard/create/${data.slug}`)
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Something went wrong",
        variant: "destructive",
      })
    },
  })

  const onSubmit: SubmitHandler<CreateCourseInput> = async (data) => {
    if (!session) {
      toast({
        title: "Authentication Required",
        description: "Please sign in to create a course.",
        variant: "destructive",
      })
      signIn()
      return
    }
    if (!subscriptionStatus?.isSubscribed && (availableCredits ?? 0) === 0) {
      toast({
        title: "Subscription or Credits Required",
        description: "Please subscribe or buy credits to create a course.",
        variant: "destructive",
      })
      router.push("dashboard/subscription")
      return
    }
    setShowConfirmDialog(true)
  }

  const handleConfirmCreate = async () => {
    setShowConfirmDialog(false)
    if (!subscriptionStatus?.isSubscribed && (availableCredits ?? 0) === 0) {
      toast({
        title: "No Credits Available",
        description: "You don't have enough credits to create a course. Please subscribe or buy more credits.",
        variant: "destructive",
      })
      router.push("dashboard/subscription")
      return
    }
    await createCourseMutation.mutateAsync(watch())
  }

  const handleNext = () => setStep(step + 1)
  const handleBack = () => setStep(step - 1)

  const isStepValid = () => {
    if (step === 1) {
      return !!watch("title") && !!watch("description") && !!watch("category")
    } else if (step === 2) {
      return watch("units").length > 0 && watch("units").every((unit) => !!unit)
    }
    return true
  }

  const isCreateDisabled =
    step !== 3 ||
    !session ||
    (!subscriptionStatus?.isSubscribed && (availableCredits ?? 0) === 0) ||
    isSubmitting ||
    createCourseMutation.status === "pending" ||
    showConfirmDialog

  const steps = [
    { icon: <Pencil className="h-5 w-5" />, label: "Basic Info" },
    { icon: <FileText className="h-5 w-5" />, label: "Content" },
    { icon: <Eye className="h-5 w-5" />, label: "Preview" },
  ]

  return (
    <div className="min-h-screen bg-background">
         <div className="container mx-auto px-4 py-6 md:py-8 lg:py-10 max-w-3xl">
        <div className="bg-card rounded-lg shadow-sm overflow-hidden">
          <div className="bg-muted/40 px-4 py-6 sm:px-6">
            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-center text-foreground">
              Create a New Course
            </h1>
            <p className="text-center text-sm sm:text-base text-muted-foreground mt-2">
              Fill in the details for your new course. Progress is automatically saved.
            </p>
          </div>

          <Separator />

          <div className="p-4 sm:p-6">
            {/* Step Indicators */}
            <div className="relative mb-6 md:mb-8">
              <div className="flex justify-between items-center relative z-10">
                {steps.map((s, i) => (
                  <div
                    key={i}
                    className={cn(
                      "flex flex-col items-center",
                      i + 1 === step ? "text-primary" : "text-muted-foreground",
                    )}
                  >
                    <div
                      className={cn(
                        "w-10 h-10 sm:w-12 sm:h-12 rounded-full flex items-center justify-center mb-2 transition-colors",
                        i + 1 === step ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground",
                      )}
                    >
                      {s.icon}
                    </div>
                    <span className="text-xs sm:text-sm font-medium">{s.label}</span>
                  </div>
                ))}
              </div>

              {/* Progress Bar */}
              <div className="mt-6 sm:mt-8">
                <Progress value={((step - 1) / (totalSteps - 1)) * 100} className="h-2 transition-all duration-300" />
              </div>
            </div>

            {/* Form Content */}
            <div className="mt-6 md:mt-8 space-y-6">
              {step === 1 && <BasicInfoStep control={control} errors={errors} params={params} />}
              {step === 2 && <ContentStep control={control} errors={errors} watch={watch} setValue={setValue} />}
              {step === 3 && <PreviewStep watch={watch} />}
            </div>

            {/* Navigation Buttons */}
            <div className="flex flex-col sm:flex-row sm:justify-between mt-8 gap-4">
              <Button
                type="button"
                variant="outline"
                onClick={handleBack}
                disabled={step === 1}
                className="w-full sm:w-auto"
              >
                Back
              </Button>

              <div className="space-y-2 w-full sm:w-auto">
                {step < totalSteps ? (
                  <Button
                    type="button"
                    onClick={handleNext}
                    disabled={!isStepValid() || maxQuestions === 0}
                    className="w-full sm:w-auto"
                  >
                    Continue
                  </Button>
                ) : (
                  <Button
                    type="submit"
                    disabled={isCreateDisabled}
                    onClick={handleSubmit(onSubmit)}
                    className="w-full sm:w-auto"
                  >
                    {isSubmitting || createCourseMutation.status === "pending" ? "Creating Course..." : "Create Course"}
                  </Button>
                )}

                {!subscriptionStatus?.isSubscribed && (availableCredits ?? 0) > 0 && (
                  <p className="text-xs sm:text-sm text-muted-foreground text-center sm:text-right">
                    Available credits: {availableCredits} (This action will deduct 1 credit)
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      <ConfirmationDialog
        open={showConfirmDialog}
        onOpenChange={setShowConfirmDialog}
        onConfirm={handleConfirmCreate}
        formData={watch()}
        isSubmitting={isSubmitting || createCourseMutation.status === "pending"}
      />
    </div>
  )
}

