"use client"

import { useSession } from "next-auth/react"
import { useSearchParams } from "next/navigation"
import useSubscriptionStore from "@/store/useSubscriptionStore"
import { SUBSCRIPTION_PLANS } from "@/config/subscriptionPlans"
import type { QueryParams } from "@/app/types/types"
import CreateQuizForm from "./features/quiz/CreateQuizForm"
import CodeQuizForm from "./features/code/CodeQuizForm"
import OpenEndedQuizForm from "./features/openended/OpenEndedQuizForm"
import CreateCourseForm from "./features/create/CreateCourseForm"
import FillInTheBlankQuizForm from "./features/blanks/BlankQuizForm"

import { Loader2 } from "lucide-react"
import ConsistentCard from "./ConsistentCard"
import FlashCardCreate from "@/app/dashboard/flashcard/components/FlashCardCreate"

type QuizType = "mcq" | "openended" | "fill-in-the-blanks" | "course" | "code"| "flashcard"

interface QuizWrapperProps {
  type: QuizType
  queryParams?: QueryParams
}

export function QuizWrapper({ type, queryParams }: QuizWrapperProps) {
  const { subscriptionStatus } = useSubscriptionStore()
  const { data: session, status } = useSession()
  const searchParams = useSearchParams()

  // Merge URL search params with provided queryParams
  const params: QueryParams = {
    ...Object.fromEntries(searchParams?.entries() ?? []),
    ...queryParams,
  }

  const subscriptionPlan = subscriptionStatus ? subscriptionStatus.subscriptionPlan : "FREE"
  const plan = SUBSCRIPTION_PLANS.find((plan) => plan.name === subscriptionPlan)

  const getMaxQuestions = () => {
    return plan?.limits.maxQuestionsPerQuiz || 0
  }

  const isLoggedIn = !!session?.user
  const maxQuestions = getMaxQuestions()
  const credits = subscriptionStatus?.credits || 0

  const commonProps = {
    maxQuestions,
    subscriptionPlan,
    isLoggedIn,
    credits,
    params,
  }

  const renderQuizForm = () => {
    switch (type) {
      case "mcq":
        return <CreateQuizForm {...commonProps} />
      case "openended":
        return <OpenEndedQuizForm {...commonProps} />
      case "fill-in-the-blanks":
        return <FillInTheBlankQuizForm {...commonProps} />
      case "course":
        return <CreateCourseForm {...commonProps} />
      case "code":
        return <CodeQuizForm {...commonProps} />
      case "flashcard":
        return <FlashCardCreate {...commonProps} />
      default:
        return null
    }
  }

  if (status === "loading") {
    return (
      <ConsistentCard>
        <div className="flex items-center justify-center h-64">
          <Loader2 className="w-8 h-8 animate-spin" />
        </div>
      </ConsistentCard>
    )
  }

  return (
    <>
      {renderQuizForm()}
    </>
  )
}

