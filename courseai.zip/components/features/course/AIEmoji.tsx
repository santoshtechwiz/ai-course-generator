import Logo from "@/components/shared/Logo"
import type React from "react"



const AIEmoji: React.FC = () => {
  return (
    <Logo></Logo>
  )
}

export default AIEmoji

