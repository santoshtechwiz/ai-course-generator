// "use client"

// import type { Table } from "@tanstack/react-table"


// interface DataTablePaginationProps<TData> {
//   table: Table<TData>
// }

// export function DataTablePagination<TData>({ table }: DataTablePaginationProps<TData>) {
//   return (
//     <Pagination
//       onPageChange={(page) => table.setPageIndex(page)}
//       currentPage={table.getState().pagination.pageIndex + 1}
//       pageSize={table.getState().pagination.pageSize}
//       totalCount={table.getRowModel().rows.length}
//     />
//   )
// }

